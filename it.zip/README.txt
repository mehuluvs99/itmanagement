IT Asset Management - PHP + MySQL (Full Professional Package)
=============================================================
Files included:
- config.php
- index.php (dashboard, protected)
- login.php, signup.php, logout.php
- admin/ (user management)
- backend/ (assets CRUD APIs)
- assets/ (css, images)
- app.js (frontend asset manager JS)
- auth.js (frontend auth helpers)
- db_schema.sql (create DB + tables)

Installation (GoDaddy / cPanel):
1. Upload files to public_html (or desired folder).
2. Edit config.php to match DB credentials (already prefilled).
3. In phpMyAdmin import db_schema.sql (or run SQL statements).
4. Ensure file permissions allow PHP execution.
5. Visit /signup.php to create users or login with admin user.
6. Change admin password immediately.

Security notes:
- Change default admin password after first login.
- Consider enforcing HTTPS and stronger JWT/session protections for production.

