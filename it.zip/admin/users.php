<?php
require '../config.php';
if (!isset($_SESSION['userid']) || $_SESSION['role']!='admin') { header('Location: ../login.php'); exit; }

if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['create'])) {
  $u=$_POST['username']; $e=$_POST['email']; $p=password_hash($_POST['password'], PASSWORD_DEFAULT); $r=$_POST['role'];
  $stmt=$conn->prepare('INSERT INTO users (username,email,password,role) VALUES (?,?,?,?)'); $stmt->bind_param('ssss',$u,$e,$p,$r); $stmt->execute();
  header('Location: users.php'); exit;
}

$users = $conn->query('SELECT id,username,email,role,created_at FROM users ORDER BY id DESC');
?>
<!doctype html><html><head><meta charset="utf-8"><title>Users</title><script src="https://cdn.tailwindcss.com"></script></head><body class="p-6">
<h2 class="text-xl font-bold mb-4">User Management</h2>
<div class="mb-4">
  <form method="POST" class="grid grid-cols-1 md:grid-cols-4 gap-2">
    <input name="username" placeholder="Username" class="p-2 border rounded">
    <input name="email" placeholder="Email" class="p-2 border rounded">
    <input name="password" placeholder="Password" class="p-2 border rounded">
    <select name="role" class="p-2 border rounded"><option value="employee">Employee</option><option value="admin">Admin</option></select>
    <button name="create" class="bg-green-600 text-white p-2 rounded col-span-4 md:col-span-1">Create</button>
  </form>
</div>
<table class="min-w-full bg-white"><thead><tr><th>ID</th><th>Username</th><th>Email</th><th>Role</th><th>Created</th></tr></thead><tbody>
<?php while($row=$users->fetch_assoc()): ?>
<tr><td><?php echo $row['id']; ?></td><td><?php echo htmlspecialchars($row['username']); ?></td><td><?php echo htmlspecialchars($row['email']); ?></td><td><?php echo $row['role']; ?></td><td><?php echo $row['created_at']; ?></td></tr>
<?php endwhile; ?>
</tbody></table>
<p class="mt-4"><a href="../index.php" class="text-blue-600">Back to dashboard</a></p>
</body></html>
