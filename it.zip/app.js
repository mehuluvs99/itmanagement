// app.js - frontend logic to load assets from PHP backend
document.addEventListener('DOMContentLoaded', () => {
  loadAssets();
  document.getElementById('search').addEventListener('input', () => { loadAssets(); });
  document.getElementById('form-asset').addEventListener('submit', saveAsset);
});

async function loadAssets() {
  try {
    const res = await fetch('backend/getAssets.php');
    const data = await res.json();
    if (!data.success) return;
    const list = data.records;
    const tbody = document.getElementById('assets-body');
    tbody.innerHTML = '';
    let total=0, active=0, maintenance=0;
    list.forEach(a=>{
      total++;
      if (a.status==='Active') active++;
      if (a.status==='Maintenance') maintenance++;
      tbody.innerHTML += `<tr>
        <td class="p-2">${a.id}</td>
        <td class="p-2">${escapeHtml(a.asset_name || '')}</td>
        <td class="p-2">${escapeHtml(a.category || '')}</td>
        <td class="p-2">${escapeHtml(a.status || '')}</td>
        <td class="p-2">${escapeHtml(a.assigned_to || '')}</td>
        <td class="p-2">
          <button onclick="editAsset(${a.id})" class="text-blue-600 mr-2">Edit</button>
          <button onclick="deleteAsset(${a.id})" class="text-red-600">Delete</button>
        </td>
      </tr>`;
    });
    document.getElementById('total-assets').textContent = total;
    document.getElementById('active-assets').textContent = active;
    document.getElementById('maintenance-assets').textContent = maintenance;
  } catch (e) {
    console.error(e);
  }
}

function escapeHtml(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

function showAddForm(){ document.getElementById('asset-form').classList.remove('hidden'); }
function hideForm(){ document.getElementById('asset-form').classList.add('hidden'); document.getElementById('form-asset').reset(); document.getElementById('asset-id').value=''; }

async function saveAsset(e){
  e.preventDefault();
  const id = document.getElementById('asset-id').value;
  const payload = {
    id: id || null,
    asset_name: document.getElementById('asset-name').value,
    asset_tag: document.getElementById('asset-tag').value,
    category: document.getElementById('asset-category').value,
    status: document.getElementById('asset-status').value,
    manufacturer: document.getElementById('asset-manufacturer') ? document.getElementById('asset-manufacturer').value : '',
    model: document.getElementById('asset-model') ? document.getElementById('asset-model').value : '',
    serial_number: document.getElementById('asset-serial') ? document.getElementById('asset-serial').value : '',
    location: document.getElementById('asset-location').value,
    purchase_date: document.getElementById('asset-purchase') ? document.getElementById('asset-purchase').value : '',
    purchase_cost: document.getElementById('asset-cost').value || 0,
    warranty_expiry: document.getElementById('asset-warranty') ? document.getElementById('asset-warranty').value : '',
    assigned_to: document.getElementById('asset-assigned').value,
    notes: document.getElementById('asset-notes').value
  };
  try {
    const url = id ? 'backend/updateAsset.php' : 'backend/addAsset.php';
    const res = await fetch(url, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data.success) {
      hideForm(); loadAssets();
    } else {
      alert('Error saving asset');
    }
  } catch(e){ console.error(e); alert('Error'); }
}

async function editAsset(id) {
  // fetch single asset from list - quick method: reload and find
  const res = await fetch('backend/getAssets.php');
  const data = await res.json();
  const asset = data.records.find(a=>a.id==id);
  if (!asset) return;
  document.getElementById('asset-id').value = asset.id;
  document.getElementById('asset-name').value = asset.asset_name || '';
  document.getElementById('asset-tag').value = asset.asset_tag || '';
  document.getElementById('asset-category').value = asset.category || '';
  document.getElementById('asset-status').value = asset.status || '';
  document.getElementById('asset-assigned').value = asset.assigned_to || '';
  document.getElementById('asset-location').value = asset.location || '';
  document.getElementById('asset-purchase').value = asset.purchase_date || '';
  document.getElementById('asset-cost').value = asset.purchase_cost || '';
  document.getElementById('asset-notes').value = asset.notes || '';
  showAddForm();
}

async function deleteAsset(id) {
  if (!confirm('Delete this asset?')) return;
  const res = await fetch('backend/deleteAsset.php', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({id})
  });
  const data = await res.json();
  if (data.success) loadAssets();
}
