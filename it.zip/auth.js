// auth.js - helper to check login via simple endpoint (session-based)
async function getSession() {
  try {
    const res = await fetch('backend/session.php');
    if (!res.ok) return null;
    return await res.json();
  } catch (e) { return null; }
}
