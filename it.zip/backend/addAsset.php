<?php
require '../config.php';
if (!isset($_SESSION['userid'])) { http_response_code(401); echo json_encode(['error'=>'unauthorized']); exit; }
$data = json_decode(file_get_contents('php://input'), true);
$uid = $_SESSION['userid'];

$stmt = $conn->prepare('INSERT INTO assets (user_id, asset_name, asset_tag, category, status, manufacturer, model, serial_number, location, purchase_date, purchase_cost, warranty_expiry, assigned_to, notes) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
$stmt->bind_param('isssssssssssss',
  $uid,
  $data['asset_name'],
  $data['asset_tag'],
  $data['category'],
  $data['status'],
  $data['manufacturer'],
  $data['model'],
  $data['serial_number'],
  $data['location'],
  $data['purchase_date'],
  $data['purchase_cost'],
  $data['warranty_expiry'],
  $data['assigned_to'],
  $data['notes']
);
$stmt->execute();
echo json_encode(['success'=>true]);
?>