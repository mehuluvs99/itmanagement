<?php
require '../config.php';
if (!isset($_SESSION['userid'])) { http_response_code(401); echo json_encode(['error'=>'unauthorized']); exit; }
$data = json_decode(file_get_contents('php://input'), true);
$id = intval($data['id']);
$uid = $_SESSION['userid'];
// allow delete if owner or admin
if ($_SESSION['role']=='admin') {
  $conn->query("DELETE FROM assets WHERE id = $id");
} else {
  $conn->query("DELETE FROM assets WHERE id = $id AND user_id = $uid");
}
echo json_encode(['success'=>true]);
?>