<?php
require '../config.php';
if (!isset($_SESSION['userid'])) { http_response_code(401); echo json_encode(['error'=>'unauthorized']); exit; }
$uid = $_SESSION['userid'];
$sql = "SELECT * FROM assets";
if ($_SESSION['role']!='admin') {
  $sql = "SELECT * FROM assets WHERE user_id = ".$uid;
}
$res = $conn->query($sql);
$out = [];
while($r = $res->fetch_assoc()) $out[] = $r;
echo json_encode(['success'=>true,'records'=>$out]);
?>