<?php
require '../config.php';
if(isset($_SESSION['userid'])) {
  echo json_encode(['loggedin'=>true,'username'=>$_SESSION['username'],'role'=>$_SESSION['role']]);
} else {
  echo json_encode(['loggedin'=>false]);
}
?>