<?php
require '../config.php';
if (!isset($_SESSION['userid'])) { http_response_code(401); echo json_encode(['error'=>'unauthorized']); exit; }
$data = json_decode(file_get_contents('php://input'), true);
$id = intval($data['id']);
$uid = $_SESSION['userid'];

$stmt = $conn->prepare('UPDATE assets SET asset_name=?, asset_tag=?, category=?, status=?, manufacturer=?, model=?, serial_number=?, location=?, purchase_date=?, purchase_cost=?, warranty_expiry=?, assigned_to=?, notes=? WHERE id=? AND (user_id=? OR ?=? )');
$stmt->bind_param('sssssssssssiiii',
  $data['asset_name'],
  $data['asset_tag'],
  $data['category'],
  $data['status'],
  $data['manufacturer'],
  $data['model'],
  $data['serial_number'],
  $data['location'],
  $data['purchase_date'],
  $data['purchase_cost'],
  $data['warranty_expiry'],
  $data['assigned_to'],
  $data['notes'],
  $id, $uid, $_SESSION['role'], 'admin'
);
$stmt->execute();
echo json_encode(['success'=>true]);
?>