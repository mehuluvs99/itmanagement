<?php
// config.php - database connection
$servername = "localhost";
$username = "mehuluvs99";
$password = "Mehulvs@99";
$dbname = "it_management";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Secure session settings
ini_set('session.use_only_cookies', 1); // Only use cookies for sessions
ini_set('session.use_strict_mode', 1); // Prevents session fixation

session_set_cookie_params([
    'lifetime' => 0, // Expire on browser close
    'path' => '/',
    'domain' => '', // Your domain here e.g., 'yourdomain.com'
    'secure' => isset($_SERVER['HTTPS']), // Only send cookie over HTTPS
    'httponly' => true, // Prevent JavaScript access to the session cookie
]);

session_start();
?>
