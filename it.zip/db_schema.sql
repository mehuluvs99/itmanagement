-- Database: it_management
CREATE DATABASE IF NOT EXISTS it_management;
USE it_management;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin','employee') DEFAULT 'employee',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS assets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  asset_name VARCHAR(255),
  asset_tag VARCHAR(255),
  category VARCHAR(100),
  status ENUM('Active','Maintenance','Retired') DEFAULT 'Active',
  manufacturer VARCHAR(255),
  model VARCHAR(255),
  serial_number VARCHAR(255),
  location VARCHAR(255),
  purchase_date DATE,
  purchase_cost DECIMAL(10,2),
  warranty_expiry DATE,
  assigned_to VARCHAR(255),
  notes TEXT,
  date_added TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create an initial admin user (password: Admin@123) - change after first login
INSERT IGNORE INTO users (username, email, password, role)
VALUES ('admin', 'admin@workflowmanagement.in', CONCAT('$2y$10$', SUBSTRING(MD5(RAND()),1,22)), 'admin');
