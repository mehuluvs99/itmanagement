<?php
require 'config.php';
if (!isset($_SESSION['userid'])) { header('Location: login.php'); exit; }
// fetch username and role
$userid = $_SESSION['userid'];
$username = $_SESSION['username'];
$role = $_SESSION['role'];
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>IT Asset Manager - Dashboard</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">
  <nav class="bg-blue-600 text-white p-4">
    <div class="container mx-auto flex justify-between">
      <div class="font-bold">IT Asset Manager</div>
      <div>
        <span class="mr-4">Hello, <?php echo htmlspecialchars($username); ?> (<?php echo $role; ?>)</span>
        <a href="logout.php" class="underline">Logout</a>
      </div>
    </div>
  </nav>

  <main class="container mx-auto p-6">
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
      <div class="bg-white p-4 rounded shadow">
        <h3 class="text-sm text-gray-500">Total Assets</h3>
        <p id="total-assets" class="text-2xl font-bold">0</p>
      </div>
      <div class="bg-white p-4 rounded shadow">
        <h3 class="text-sm text-gray-500">Active</h3>
        <p id="active-assets" class="text-2xl font-bold">0</p>
      </div>
      <div class="bg-white p-4 rounded shadow">
        <h3 class="text-sm text-gray-500">Maintenance</h3>
        <p id="maintenance-assets" class="text-2xl font-bold">0</p>
      </div>
    </div>

    <div class="bg-white p-4 rounded shadow mb-6">
      <div class="flex justify-between items-center mb-4">
        <h2 class="text-xl font-bold">Assets</h2>
        <div>
          <?php if($role=='admin'): ?>
            <a href="admin/users.php" class="text-sm text-blue-600 mr-4">Manage Users</a>
          <?php endif; ?>
          <button onclick="showAddForm()" class="bg-blue-600 text-white px-4 py-2 rounded">Add Asset</button>
        </div>
      </div>

      <div class="mb-4">
        <input id="search" placeholder="Search..." class="p-2 border rounded w-full">
      </div>

      <div class="overflow-x-auto">
        <table id="assets-table" class="min-w-full">
          <thead>
            <tr>
              <th class="text-left p-2">ID</th>
              <th class="text-left p-2">Name</th>
              <th class="text-left p-2">Category</th>
              <th class="text-left p-2">Status</th>
              <th class="text-left p-2">Assigned To</th>
              <th class="text-left p-2">Actions</th>
            </tr>
          </thead>
          <tbody id="assets-body"></tbody>
        </table>
      </div>
    </div>

    <div id="asset-form" class="bg-white p-4 rounded shadow hidden">
      <h3 class="font-bold mb-4">Add / Edit Asset</h3>
      <form id="form-asset">
        <input type="hidden" id="asset-id">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <input id="asset-name" placeholder="Asset Name" class="p-2 border rounded">
          <input id="asset-tag" placeholder="Asset Tag" class="p-2 border rounded">
          <select id="asset-category" class="p-2 border rounded">
            <option value="">Category</option>
            <option>Hardware</option>
            <option>Software</option>
            <option>Network</option>
            <option>Mobile</option>
            <option>Other</option>
          </select>
          <select id="asset-status" class="p-2 border rounded">
            <option>Active</option>
            <option>Maintenance</option>
            <option>Retired</option>
          </select>
          <input id="asset-assigned" placeholder="Assigned To" class="p-2 border rounded">
          <input id="asset-location" placeholder="Location" class="p-2 border rounded">
          <input id="asset-purchase" type="date" class="p-2 border rounded">
<input id="asset-manufacturer" placeholder="Manufacturer" class="p-2 border rounded mt-2">
<input id="asset-model" placeholder="Model" class="p-2 border rounded mt-2">
<input id="asset-serial" placeholder="Serial Number" class="p-2 border rounded mt-2">
<input id="asset-warranty" type="date" class="p-2 border rounded mt-2">
          <input id="asset-cost" type="number" step="0.01" placeholder="Cost" class="p-2 border rounded">
        </div>
        <div class="mt-4">
          <textarea id="asset-notes" placeholder="Notes" class="w-full p-2 border rounded"></textarea>
        </div>
        <div class="mt-4">
          <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded">Save</button>
          <button type="button" onclick="hideForm()" class="ml-2 px-4 py-2">Cancel</button>
        </div>
      </form>
    </div>

  </main>

<script src="auth.js"></script>
<script src="app.js"></script>
</body>
</html>
