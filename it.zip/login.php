<?php
require 'config.php';

// If user is already logged in, redirect to dashboard
if (isset($_SESSION['userid'])) {
    header('Location: index.php');
    exit;
}

// --- Generate CSRF state token ---
if (empty($_SESSION['oauth_state'])) {
    $_SESSION['oauth_state'] = bin2hex(random_bytes(32));
}

// --- Google Login URL with state ---
$google_login_url = 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query([
    'scope' => 'email profile',
    'redirect_uri' => defined('GOOGLE_REDIRECT_URI') ? GOOGLE_REDIRECT_URI : '',
    'response_type' => 'code',
    'client_id' => defined('GOOGLE_CLIENT_ID') ? GOOGLE_CLIENT_ID : '',
    'access_type' => 'offline',
    'state' => $_SESSION['oauth_state'] // Add state parameter
]);

// --- Microsoft Login URL with state ---
$microsoft_login_url = 'https://login.microsoftonline.com/' . (defined('MICROSOFT_TENANT') ? MICROSOFT_TENANT : 'common') . '/oauth2/v2.0/authorize?' . http_build_query([
    'client_id' => defined('MICROSOFT_CLIENT_ID') ? MICROSOFT_CLIENT_ID : '',
    'response_type' => 'code',
    'redirect_uri' => defined('MICROSOFT_REDIRECT_URI') ? MICROSOFT_REDIRECT_URI : '',
    'response_mode' => 'query',
    'scope' => 'User.Read',
    'state' => $_SESSION['oauth_state'] // Add state parameter
]);

$err='';
if ($_SERVER['REQUEST_METHOD']=='POST') {
  $email = $_POST['email']; $pass = $_POST['password'];
  $stmt = $conn->prepare('SELECT id, username, password, role FROM users WHERE email = ?');
  $stmt->bind_param('s', $email); $stmt->execute(); $stmt->store_result();
  if ($stmt->num_rows==1) {
    $stmt->bind_result($id,$u,$h,$role); $stmt->fetch();
    if (password_verify($pass, $h)) {
      $_SESSION['userid']=$id; $_SESSION['username']=$u; $_SESSION['role']=$role;
      header('Location: index.php'); exit;
    }
  }
  $err = 'Invalid credentials';
}
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Login</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
  <div class="bg-white p-6 rounded shadow w-full max-w-md">
    <h2 class="text-xl font-bold mb-4">Login</h2>
    <?php if($err): ?><div class="bg-red-100 p-2 text-red-700 mb-3"><?php echo $err; ?></div><?php endif; ?>
    <form method="POST">
      <input name="email" placeholder="Email" required class="w-full p-2 border rounded mb-2">
      <input name="password" type="password" placeholder="Password" required class="w-full p-2 border rounded mb-2">
      <button class="w-full bg-blue-600 text-white p-2 rounded">Login</button>
    </form>

    <div class="my-6 flex items-center justify-center">
        <hr class="w-full border-gray-300">
        <span class="px-4 bg-white text-gray-500">OR</span>
        <hr class="w-full border-gray-300">
    </div>

    <!-- Social Login Buttons -->
    <div class="space-y-4">
        <a href="<?php echo htmlspecialchars($google_login_url); ?>" class="w-full flex items-center justify-center bg-white border border-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-50 transition duration-200">
            Continue with Google
        </a>
        <a href="<?php echo htmlspecialchars($microsoft_login_url); ?>" class="w-full flex items-center justify-center bg-white border border-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-50 transition duration-200">
            Continue with Microsoft
        </a>
    </div>
    <p class="mt-3 text-sm">Don't have an account? <a href="signup.php" class="text-blue-600">Sign up</a></p>
  </div>
</body>
</html>
