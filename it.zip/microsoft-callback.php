<?php
require 'config.php';

// 1. Verify the state token to prevent CSRF
if (empty($_GET['state']) || empty($_SESSION['oauth_state']) || $_GET['state'] !== $_SESSION['oauth_state']) {
    unset($_SESSION['oauth_state']);
    header('Location: login.php?error=invalid_state');
    exit('Invalid state');
}

if (!isset($_GET['code'])) {
    header('Location: login.php?error=no_code');
    exit('Error: No authorization code received.');
}

$code = $_GET['code'];

// 1. Exchange authorization code for an access token
$token_url = 'https://login.microsoftonline.com/' . MICROSOFT_TENANT . '/oauth2/v2.0/token';
$token_params = [
    'client_id' => MICROSOFT_CLIENT_ID,
    'scope' => 'User.Read',
    'code' => $code,
    'redirect_uri' => MICROSOFT_REDIRECT_URI,
    'grant_type' => 'authorization_code',
    'client_secret' => MICROSOFT_CLIENT_SECRET,
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $token_url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($token_params));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

$token_data = json_decode($response, true);

if (!isset($token_data['access_token'])) {
    die('Error fetching access token: ' . ($token_data['error_description'] ?? 'Unknown error'));
}

$access_token = $token_data['access_token'];

// 2. Use access token to get user info from Microsoft Graph API
$userinfo_url = 'https://graph.microsoft.com/v1.0/me';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $userinfo_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $access_token]);
$user_response = curl_exec($ch);
curl_close($ch);

$user_data = json_decode($user_response, true);

if (!isset($user_data['userPrincipalName'])) {
    die('Error fetching user information.');
}

$email = $user_data['userPrincipalName']; // This is usually the email
$name = $user_data['displayName'] ?? 'Microsoft User';

// 3. Find or create user in your database
$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch();

if ($user) {
    // User exists, log them in
    $_SESSION['userid'] = $user['id'];
    // Regenerate session ID to prevent session fixation
    session_regenerate_id(true);
    $_SESSION['username'] = $user['username'];
    $_SESSION['role'] = $user['role'];
} else {
    // User does not exist, create a new one
    $password = password_hash(bin2hex(random_bytes(16)), PASSWORD_DEFAULT); // Secure random password
    $role = 'user'; // Default role

    $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
    $stmt->execute([$name, $email, $password, $role]);
    $new_user_id = $pdo->lastInsertId();

    // Log the new user in
    $_SESSION['userid'] = $new_user_id;
    // Regenerate session ID to prevent session fixation
    session_regenerate_id(true);
    $_SESSION['username'] = $name;
    $_SESSION['role'] = $role;
}

// 4. Redirect to the dashboard
header('Location: index.php');
exit;