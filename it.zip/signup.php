<?php
require 'config.php';
if (isset($_SESSION['userid'])) { header('Location: index.php'); exit; }
$err='';
if ($_SERVER['REQUEST_METHOD']=='POST') {
  $username = $_POST['username']; $email = $_POST['email']; $password = $_POST['password'];
  $hash = password_hash($password, PASSWORD_DEFAULT);
  $stmt = $conn->prepare('INSERT INTO users (username,email,password,role) VALUES (?,?,?,?)');
  $role = 'employee';
  $stmt->bind_param('ssss',$username,$email,$hash,$role);
  if ($stmt->execute()) {
    header('Location: login.php'); exit;
  } else {
    $err = 'Unable to register (email may exist)';
  }
}
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Sign up</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
  <div class="bg-white p-6 rounded shadow w-full max-w-md">
    <h2 class="text-xl font-bold mb-4">Sign up</h2>
    <?php if($err): ?><div class="bg-red-100 p-2 text-red-700 mb-3"><?php echo $err; ?></div><?php endif; ?>
    <form method="POST">
      <input name="username" placeholder="Username" required class="w-full p-2 border rounded mb-2">
      <input name="email" placeholder="Email" required class="w-full p-2 border rounded mb-2">
      <input name="password" type="password" placeholder="Password" required class="w-full p-2 border rounded mb-2">
      <button class="w-full bg-green-600 text-white p-2 rounded">Create account</button>
    </form>
    <p class="mt-3 text-sm">Already have an account? <a href="login.php" class="text-blue-600">Login</a></p>
  </div>
</body>
</html>
